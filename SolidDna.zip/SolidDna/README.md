# SolidDNA SDK
The new SolidDNA SDK, making the SolidWorks API easier, well behaved and modern

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


